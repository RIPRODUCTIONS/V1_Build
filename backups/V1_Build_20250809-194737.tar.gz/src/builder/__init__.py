from __future__ import annotations

__all__: list[str] = []
__version__ = "0.1.0"
